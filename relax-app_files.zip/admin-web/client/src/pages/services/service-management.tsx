import { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings, Plus, Edit, Trash2, DollarSign, Clock, Users, Sparkles, Package, Tag } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

interface Service {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  duration: number; // in minutes
  category: string;
  isActive: boolean;
  popularity: number;
  totalBookings: number;
  averageRating: number;
  createdAt: Date;
}

interface ServiceCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  serviceCount: number;
  isActive: boolean;
}

const sampleServices: Service[] = [
  {
    id: "1",
    name: "Limpeza Residencial Básica",
    description: "Limpeza completa de casa incluindo quartos, banheiros, cozinha e sala",
    basePrice: 120.00,
    duration: 180,
    category: "residential",
    isActive: true,
    popularity: 95,
    totalBookings: 1247,
    averageRating: 4.8,
    createdAt: new Date("2023-01-15")
  },
  {
    id: "2",
    name: "Limpeza Pós-Obra",
    description: "Limpeza especializada após reformas e construções",
    basePrice: 250.00,
    duration: 300,
    category: "specialized",
    isActive: true,
    popularity: 78,
    totalBookings: 456,
    averageRating: 4.9,
    createdAt: new Date("2023-02-20")
  },
  {
    id: "3",
    name: "Limpeza de Escritório",
    description: "Limpeza profissional para ambientes corporativos",
    basePrice: 180.00,
    duration: 240,
    category: "commercial",
    isActive: true,
    popularity: 67,
    totalBookings: 789,
    averageRating: 4.7,
    createdAt: new Date("2023-03-10")
  },
  {
    id: "4",
    name: "Limpeza de Vidros",
    description: "Limpeza profissional de vidros internos e externos",
    basePrice: 80.00,
    duration: 120,
    category: "specialized",
    isActive: false,
    popularity: 45,
    totalBookings: 234,
    averageRating: 4.6,
    createdAt: new Date("2023-04-05")
  }
];

const serviceCategories: ServiceCategory[] = [
  {
    id: "residential",
    name: "Residencial",
    description: "Serviços de limpeza para casas e apartamentos",
    icon: "🏠",
    serviceCount: 1,
    isActive: true
  },
  {
    id: "commercial",
    name: "Comercial",
    description: "Limpeza para escritórios e estabelecimentos comerciais",
    icon: "🏢",
    serviceCount: 1,
    isActive: true
  },
  {
    id: "specialized",
    name: "Especializada",
    description: "Serviços especializados como pós-obra e limpeza de vidros",
    icon: "⭐",
    serviceCount: 2,
    isActive: true
  }
];

export default function ServiceManagement() {
  const [services, setServices] = useState(sampleServices);
  const [categories] = useState(serviceCategories);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [isAddServiceOpen, setIsAddServiceOpen] = useState(false);
  const [isEditServiceOpen, setIsEditServiceOpen] = useState(false);
  const { toast } = useToast();

  const handleToggleService = (serviceId: string) => {
    setServices(services.map(service => 
      service.id === serviceId 
        ? { ...service, isActive: !service.isActive }
        : service
    ));
    
    toast({
      title: "Service Updated",
      description: "Service status has been updated successfully.",
    });
  };

  const handleDeleteService = (serviceId: string) => {
    setServices(services.filter(service => service.id !== serviceId));
    toast({
      title: "Service Deleted",
      description: "Service has been removed successfully.",
    });
  };

  const activeServices = services.filter(s => s.isActive).length;
  const totalRevenue = services.reduce((sum, service) => sum + (service.basePrice * service.totalBookings), 0);
  const avgRating = services.reduce((sum, service) => sum + service.averageRating, 0) / services.length;

  return (
    <div className="flex h-screen bg-admin-bg">
      <Sidebar />
      
      <div className="flex-1 ml-72 overflow-hidden">
        <Header 
          title="Service Management"
          subtitle="Manage cleaning services, pricing, and categories."
        />
        
        <main className="flex-1 overflow-y-auto p-8">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <Card className="shadow-floating border-0">
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <Package className="text-blue-600" size={20} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Services</p>
                    <p className="text-2xl font-bold text-gray-900">{services.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-floating border-0">
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <Sparkles className="text-green-600" size={20} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Active Services</p>
                    <p className="text-2xl font-bold text-gray-900">{activeServices}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-floating border-0">
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                    <DollarSign className="text-purple-600" size={20} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                    <p className="text-2xl font-bold text-gray-900">R$ {totalRevenue.toLocaleString('pt-BR')}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-floating border-0">
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
                    <Users className="text-yellow-600" size={20} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Avg Rating</p>
                    <p className="text-2xl font-bold text-gray-900">{avgRating.toFixed(1)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="services" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 bg-white shadow-floating border-0">
              <TabsTrigger value="services" className="flex items-center gap-2">
                <Package size={16} />
                Services
              </TabsTrigger>
              <TabsTrigger value="categories" className="flex items-center gap-2">
                <Tag size={16} />
                Categories
              </TabsTrigger>
            </TabsList>

            <TabsContent value="services">
              <div className="space-y-6">
                {/* Action Bar */}
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-gray-900">Service Catalog</h2>
                  
                  <Dialog open={isAddServiceOpen} onOpenChange={setIsAddServiceOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-medium-blue hover:bg-blue-700 text-white">
                        <Plus className="mr-2" size={16} />
                        Add Service
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Add New Service</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="service-name">Service Name</Label>
                            <Input id="service-name" placeholder="Enter service name" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="service-category">Category</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                              <SelectContent>
                                {categories.map(category => (
                                  <SelectItem key={category.id} value={category.id}>
                                    {category.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="service-description">Description</Label>
                          <Textarea
                            id="service-description"
                            placeholder="Describe the service..."
                            className="h-24"
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="base-price">Base Price (R$)</Label>
                            <Input id="base-price" type="number" placeholder="0.00" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="duration">Duration (minutes)</Label>
                            <Input id="duration" type="number" placeholder="120" />
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <Label>Active Service</Label>
                            <p className="text-sm text-gray-600">Enable this service for booking</p>
                          </div>
                          <Switch defaultChecked />
                        </div>
                        
                        <div className="flex justify-end space-x-3">
                          <Button variant="outline" onClick={() => setIsAddServiceOpen(false)}>
                            Cancel
                          </Button>
                          <Button className="bg-medium-blue hover:bg-blue-700 text-white">
                            Create Service
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>

                {/* Services Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {services.map((service, index) => (
                    <motion.div
                      key={service.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <Card className="shadow-floating hover:shadow-floating-lg transition-all duration-300 border-0">
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-lg">{service.name}</CardTitle>
                            <div className="flex items-center space-x-2">
                              <Badge className={service.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
                                {service.isActive ? "Active" : "Inactive"}
                              </Badge>
                              <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
                                <Settings size={16} />
                              </Button>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-600 mb-4">{service.description}</p>
                          
                          <div className="space-y-3">
                            <div className="flex items-center justify-between text-sm">
                              <span className="flex items-center text-gray-600">
                                <DollarSign size={14} className="mr-1" />
                                Base Price:
                              </span>
                              <span className="font-semibold text-green-600">
                                R$ {service.basePrice.toFixed(2)}
                              </span>
                            </div>
                            
                            <div className="flex items-center justify-between text-sm">
                              <span className="flex items-center text-gray-600">
                                <Clock size={14} className="mr-1" />
                                Duration:
                              </span>
                              <span className="font-medium">{service.duration} min</span>
                            </div>
                            
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-gray-600">Total Bookings:</span>
                              <span className="font-medium">{service.totalBookings}</span>
                            </div>
                            
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-gray-600">Avg Rating:</span>
                              <span className="font-medium">{service.averageRating}/5.0</span>
                            </div>
                            
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-medium-blue h-2 rounded-full transition-all duration-300"
                                style={{ width: `${service.popularity}%` }}
                              />
                            </div>
                            <p className="text-xs text-gray-500">Popularity: {service.popularity}%</p>
                          </div>
                          
                          <div className="flex items-center justify-between mt-6">
                            <div className="flex items-center space-x-2">
                              <Switch
                                checked={service.isActive}
                                onCheckedChange={() => handleToggleService(service.id)}
                              />
                              <span className="text-sm text-gray-600">Active</span>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-medium-blue text-medium-blue hover:bg-medium-blue hover:text-white"
                                onClick={() => {
                                  setSelectedService(service);
                                  setIsEditServiceOpen(true);
                                }}
                              >
                                <Edit size={14} />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-red-600 text-red-600 hover:bg-red-600 hover:text-white"
                                onClick={() => handleDeleteService(service.id)}
                              >
                                <Trash2 size={14} />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="categories">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-gray-900">Service Categories</h2>
                  <Button className="bg-medium-blue hover:bg-blue-700 text-white">
                    <Plus className="mr-2" size={16} />
                    Add Category
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {categories.map((category, index) => (
                    <motion.div
                      key={category.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <Card className="shadow-floating hover:shadow-floating-lg transition-all duration-300 border-0">
                        <CardContent className="pt-6">
                          <div className="text-center">
                            <div className="text-4xl mb-3">{category.icon}</div>
                            <h3 className="font-semibold text-gray-900 mb-2">{category.name}</h3>
                            <p className="text-sm text-gray-600 mb-4">{category.description}</p>
                            
                            <div className="flex items-center justify-center space-x-4 text-sm">
                              <span className="text-gray-600">
                                {category.serviceCount} services
                              </span>
                              <Badge className={category.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
                                {category.isActive ? "Active" : "Inactive"}
                              </Badge>
                            </div>
                            
                            <div className="flex items-center justify-center space-x-2 mt-4">
                              <Button variant="outline" size="sm" className="border-medium-blue text-medium-blue hover:bg-medium-blue hover:text-white">
                                <Edit size={14} />
                              </Button>
                              <Button variant="outline" size="sm" className="border-red-600 text-red-600 hover:bg-red-600 hover:text-white">
                                <Trash2 size={14} />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Edit Service Dialog */}
          <Dialog open={isEditServiceOpen} onOpenChange={setIsEditServiceOpen}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Edit Service</DialogTitle>
              </DialogHeader>
              {selectedService && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-service-name">Service Name</Label>
                      <Input id="edit-service-name" defaultValue={selectedService.name} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-service-category">Category</Label>
                      <Select defaultValue={selectedService.category}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map(category => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="edit-service-description">Description</Label>
                    <Textarea
                      id="edit-service-description"
                      defaultValue={selectedService.description}
                      className="h-24"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-base-price">Base Price (R$)</Label>
                      <Input id="edit-base-price" type="number" defaultValue={selectedService.basePrice} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-duration">Duration (minutes)</Label>
                      <Input id="edit-duration" type="number" defaultValue={selectedService.duration} />
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Active Service</Label>
                      <p className="text-sm text-gray-600">Enable this service for booking</p>
                    </div>
                    <Switch defaultChecked={selectedService.isActive} />
                  </div>
                  
                  <div className="flex justify-end space-x-3">
                    <Button variant="outline" onClick={() => setIsEditServiceOpen(false)}>
                      Cancel
                    </Button>
                    <Button className="bg-medium-blue hover:bg-blue-700 text-white">
                      Update Service
                    </Button>
                  </div>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  );
}